import { useState } from 'react';
import { Download, Copy, Check, Zap } from 'lucide-react';

function App() {
  const [copiedScript, setCopiedScript] = useState<string | null>(null);

  const handleCopy = (scriptId: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedScript(scriptId);
    setTimeout(() => setCopiedScript(null), 2000);
  };

  const scripts = [
    {
      id: 'script-1',
      name: 'Enhanced Performance',
      code: 'config.performance_mode = true\nconfig.render_distance = 512\nconfig.fps_limit = 240',
    },
    {
      id: 'script-2',
      name: 'Graphics Enhancement',
      code: 'config.graphics_level = "ultra"\nconfig.ray_tracing = true\nconfig.ambient_occlusion = true',
    },
    {
      id: 'script-3',
      name: 'Network Optimization',
      code: 'config.network_buffer = 8192\nconfig.latency_compensation = true\nconfig.packet_loss_recovery = true',
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-blue-950 to-slate-950 text-white overflow-hidden">
      <style>{`
        @keyframes glow-pulse {
          0%, 100% { text-shadow: 0 0 10px rgba(56, 189, 248, 0.6), 0 0 20px rgba(56, 189, 248, 0.4); }
          50% { text-shadow: 0 0 20px rgba(56, 189, 248, 0.9), 0 0 40px rgba(56, 189, 248, 0.6); }
        }

        @keyframes button-glow {
          0%, 100% { box-shadow: 0 0 20px rgba(56, 189, 248, 0.5), inset 0 0 20px rgba(56, 189, 248, 0.1); }
          50% { box-shadow: 0 0 40px rgba(56, 189, 248, 0.8), inset 0 0 30px rgba(56, 189, 248, 0.2); }
        }

        @keyframes border-glow {
          0%, 100% { border-color: rgba(56, 189, 248, 0.3); box-shadow: inset 0 0 15px rgba(56, 189, 248, 0.05); }
          50% { border-color: rgba(56, 189, 248, 0.6); box-shadow: inset 0 0 20px rgba(56, 189, 248, 0.1); }
        }

        @keyframes float-up {
          0% { opacity: 0; transform: translateY(20px); }
          100% { opacity: 1; transform: translateY(0); }
        }

        .glow-text {
          animation: glow-pulse 3s ease-in-out infinite;
        }

        .glow-button {
          animation: button-glow 2s ease-in-out infinite;
        }

        .glow-border {
          animation: border-glow 2.5s ease-in-out infinite;
        }

        .float-in {
          animation: float-up 0.8s ease-out;
        }

        .neon-line {
          background: linear-gradient(90deg, transparent, rgba(56, 189, 248, 0.5), transparent);
          height: 1px;
        }
      `}</style>

      <div className="relative">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-1/4 w-96 h-96 bg-blue-500 rounded-full mix-blend-screen filter blur-3xl opacity-10"></div>
          <div className="absolute top-40 right-1/4 w-96 h-96 bg-cyan-500 rounded-full mix-blend-screen filter blur-3xl opacity-10"></div>
        </div>

        <main className="relative z-10">
          <section className="min-h-screen flex flex-col items-center justify-center px-6 py-20">
            <div className="text-center max-w-4xl float-in">
              <div className="mb-4">
                <Zap className="inline-block text-blue-400 mb-6" size={48} />
              </div>

              <h1 className="text-6xl md:text-8xl font-black mb-8 glow-text leading-tight tracking-tighter">
                THE NEW ERA 1
              </h1>

              <div className="neon-line mb-8"></div>

              <p className="text-lg md:text-2xl text-blue-200 mb-12 font-light tracking-wide">
                Next Generation Gaming Modding Community
              </p>

              <p className="text-base md:text-lg text-gray-300 mb-16 max-w-2xl mx-auto leading-relaxed">
                Experience ultimate performance and visual enhancements with our professionally crafted mod configurations. Engineered for competitive advantage and visual excellence.
              </p>

              <a href="[THE NEW ERA 1]" target="_blank" rel="noopener noreferrer">
                <button className="glow-button group relative px-12 py-6 text-xl font-bold text-white bg-gradient-to-r from-blue-600 to-cyan-600 rounded-lg border border-blue-400 hover:border-blue-300 transition-all duration-300 transform hover:scale-105 flex items-center gap-3 mx-auto">
                  <Download size={28} />
                  Download Mod v1.0
                </button>
              </a>

              <p className="text-sm text-gray-300 mt-4 font-medium">
                100% Keyless & Easy to use. Just download, open, and dominate!
              </p>

              <p className="text-sm text-gray-400 mt-4">
                Version 1.0 • Optimized for peak performance • Fully compatible
              </p>
            </div>
          </section>

          <section className="py-24 px-6 bg-gradient-to-b from-transparent to-blue-950/30">
            <div className="max-w-6xl mx-auto">
              <div className="text-center mb-16">
                <h2 className="text-4xl md:text-5xl font-bold mb-4 glow-text">Script Configurations</h2>
                <div className="neon-line mb-4 w-32 mx-auto"></div>
                <p className="text-gray-300 text-lg">Copy and customize configurations for your setup</p>
              </div>

              <div className="grid md:grid-cols-3 gap-6">
                {scripts.map((script, index) => (
                  <div
                    key={script.id}
                    className="glow-border group border-2 border-blue-500/30 rounded-lg p-6 bg-slate-900/50 backdrop-blur-sm hover:bg-slate-900/70 transition-all duration-300 float-in"
                    style={{ animationDelay: `${index * 100}ms` }}
                  >
                    <h3 className="text-xl font-bold text-blue-300 mb-4 group-hover:text-blue-200 transition-colors">
                      {script.name}
                    </h3>

                    <div className="bg-slate-950/70 rounded border border-blue-900/50 p-4 mb-4 max-h-32 overflow-y-auto">
                      <code className="text-sm text-gray-300 font-mono leading-relaxed whitespace-pre-wrap break-words">
                        {script.code}
                      </code>
                    </div>

                    <button
                      onClick={() => handleCopy(script.id, script.code)}
                      className="w-full py-3 px-4 bg-blue-600/20 hover:bg-blue-600/40 border border-blue-500/50 hover:border-blue-400 rounded font-semibold text-blue-300 hover:text-blue-100 transition-all duration-300 flex items-center justify-center gap-2 group/btn"
                    >
                      {copiedScript === script.id ? (
                        <>
                          <Check size={18} />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy size={18} />
                          Copy Configuration
                        </>
                      )}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="py-24 px-6 bg-gradient-to-b from-transparent to-slate-950">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-16">
                <h2 className="text-4xl md:text-5xl font-bold mb-4 glow-text">Instant Script</h2>
                <div className="neon-line mb-4 w-32 mx-auto"></div>
                <p className="text-gray-300 text-lg">Quick access to the main loader script</p>
              </div>

              <div className="glow-border border-2 border-blue-500/30 rounded-lg p-8 bg-slate-900/50 backdrop-blur-sm max-w-2xl mx-auto">
                <div className="bg-slate-950/70 rounded border border-blue-900/50 p-6 mb-6">
                  <code className="text-sm text-gray-300 font-mono leading-relaxed break-all">
                    loadstring(game:HttpGet('raw.githubusercontent.com'))()
                  </code>
                </div>

                <button
                  onClick={() => handleCopy('instant-script', "loadstring(game:HttpGet('raw.githubusercontent.com'))()")}
                  className="w-full py-3 px-6 bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 border border-blue-400 hover:border-blue-300 rounded font-semibold text-white transition-all duration-300 flex items-center justify-center gap-2"
                >
                  {copiedScript === 'instant-script' ? (
                    <>
                      <Check size={20} />
                      Copied!
                    </>
                  ) : (
                    <>
                      <Copy size={20} />
                      Copy to Clipboard
                    </>
                  )}
                </button>
              </div>
            </div>
          </section>

          <section className="py-16 px-6 border-t border-blue-900/30 bg-gradient-to-b from-transparent via-slate-950 to-slate-950">
            <div className="max-w-4xl mx-auto text-center">
              <p className="text-gray-400 text-sm tracking-widest">
                THE NEW ERA 1 © 2024 • Professional Gaming Modding Community
              </p>
            </div>
          </section>
        </main>
      </div>
    </div>
  );
}

export default App;
